Static files are here (like images and other assets).
