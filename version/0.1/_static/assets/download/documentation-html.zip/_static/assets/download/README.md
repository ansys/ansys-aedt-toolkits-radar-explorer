Downloadable assets are stored here.
